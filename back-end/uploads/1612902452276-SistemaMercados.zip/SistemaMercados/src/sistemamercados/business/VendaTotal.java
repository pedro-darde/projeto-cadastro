/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemamercados.business;

/**
 *
 * @author Marcelo
 */
public class VendaTotal {
    private int TotalProdutos;
    private double TotalVenda;

    public int getTotalProdutos() {
        return TotalProdutos;
    }

    public void setTotalProdutos(int TotalProdutos) {
        this.TotalProdutos = TotalProdutos;
    }

    public double getTotalVenda() {
        return TotalVenda;
    }

    public void setTotalVenda(double TotalVenda) {
        this.TotalVenda = TotalVenda;
    }
    
}
